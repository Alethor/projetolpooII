
package model;


public interface Forma {
    
   
public Double calculaArea();

public Double calculaLadoOuRaio();
    
    
    
}
