
create database projetolpooii;
use projetolpooii;

create table col_cliente(
ID int NOT NULL AUTO_INCREMENT,
NOME varchar(50),
SOBRENOME varchar(50),
TELEFONE int unique,
PRIMARY KEY (ID)
);


create table col_categoria(
ID int NOT NULL AUTO_INCREMENT,
DESCRICAO varchar(50),
PRECO double,
PRIMARY KEY (ID)
);

create table col_pedido(
ID int NOT NULL AUTO_INCREMENT,
IDCLIENTE int NOT NULL,
IDSTATUS int NOT NULL,
TOTAL double,
PRIMARY KEY (ID),
FOREIGN KEY (IDCLIENTE) REFERENCES col_cliente(ID)
);

create table col_pizza_pedido(
ID int NOT NULL AUTO_INCREMENT,
IDPEDIDO int,
AREA double,
VALOR double,
FORMA char(50),
SABOR1 int,
SABOR2 int,
PRIMARY KEY (ID),
FOREIGN KEY (IDPEDIDO) REFERENCES col_pedido(ID)
);

create table col_status(
ID int NOT NULL AUTO_INCREMENT,
DESCRICAO char(50),
primary key (ID)
);

ALTER TABLE col_pedido ADD FOREIGN KEY (IDSTATUS) REFERENCES col_status(ID);

create table col_sabores(
ID int NOT NULL AUTO_INCREMENT,
IDCATEGORIA int NOT NULL,
DESCRICAO char(50),
primary key (ID)
);

create table col_formas(
ID int NOT NULL AUTO_INCREMENT,
DESCRICAO char(50),
primary key (ID)
);

ALTER TABLE col_pizza_pedido ADD FOREIGN KEY (SABOR1) REFERENCES col_sabores(ID);
ALTER TABLE col_pizza_pedido ADD FOREIGN KEY (SABOR2) REFERENCES col_sabores(ID);

insert into col_categoria(DESCRICAO, PRECO) values ("Simples", 0.5);
insert into col_categoria(DESCRICAO, PRECO) values ("Especial",0.7);
insert into col_categoria(DESCRICAO, PRECO) values ("Premium",1.0);

insert into col_formas(DESCRICAO) values ("Círculo");
insert into col_formas(DESCRICAO) values ("Quadrado");
insert into col_formas(DESCRICAO) values ("Triângulo");

insert into col_sabores(IDCATEGORIA, DESCRICAO) values (1, "Marguerita");
insert into col_sabores(IDCATEGORIA, DESCRICAO) values (2, "Troiana");
insert into col_sabores(IDCATEGORIA, DESCRICAO) values (3, "Strogonoff de Mignon");

insert into col_status(DESCRICAO) values ("Aberto");
insert into col_status(DESCRICAO) values ("A Caminho");
insert into col_status(DESCRICAO) values ("Entregue");


